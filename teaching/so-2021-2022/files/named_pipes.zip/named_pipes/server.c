#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define TAMMSG 1000

int main() {
	int fcli, fserv, n;
	char buffer[TAMMSG];

	printf("Server\n"); getchar();

	unlink("/tmp/server");
	unlink("/tmp/client");

	if (mkfifo ("/tmp/server", 0777) < 0)
		exit (1);

	if (mkfifo ("/tmp/client", 0777) < 0)
		exit (1);

	printf("Create FIFO\n"); getchar();

	fserv = open("/tmp/server", O_RDONLY);
	printf("Opened server\n");
	fcli = open("/tmp/client", O_WRONLY);
	printf("Opened client\n");

	printf("Open FIFO\n"); getchar();

	n = read(fserv, buffer, TAMMSG);
	printf("Received %d bytes: %s\n", n, buffer);

	getchar();

	strcpy(buffer, "Medíocre\n");
	write(fcli, buffer, TAMMSG);

	close(fserv);
	close(fcli);
	
	printf("Close FIFO\n"); getchar();

	unlink("/tmp/server");
	unlink("/tmp/client");

	printf("Unlink FIFO\n");

	return 0;
}
