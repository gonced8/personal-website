#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define TAMMSG 1000

int main() {
	int fcli, fserv, n;
	char buffer[TAMMSG];

	printf("Client\n"); getchar();

	fserv = open("/tmp/server", O_WRONLY);
	printf("Opened server\n");
	fcli = open("/tmp/client", O_RDONLY);
	printf("Opened client\n");

	printf("Open FIFO\n"); getchar();

	strcpy(buffer, "Como vai ser a minha nota?");
	write(fserv, buffer, TAMMSG);

	getchar();

	n = read(fcli, buffer, TAMMSG);
	printf("Received %d bytes: %s\n", n, buffer);

	close(fserv);
	close(fcli);
	
	printf("Close FIFO\n");

	return 0;
}
